package ru.geekbrains.Lesson1;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServerWindow extends JFrame {
    private JTextField jtf ;
    private JTextArea jta ;
    private final String SERVER_ADDR = "localhost" ;
    private final int SERVER_PORT = 8189; //64884 ;
    private Socket sock ;
    private Scanner in ;
    private PrintWriter out ;
    public ServerWindow(){

        ServerSocket serv = null ;
        Socket sock = null ;
        //PrintWriter pw = null;
        /*out . println ( jtf . getText ());
        out . flush ();
        jtf . setText ( "" );*/
        try {
            serv = new ServerSocket( 8189 );
            setBounds(600 , 300 , 500 , 500);
            setTitle("Server");
            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            jta = new JTextArea();
            jta.setEditable(false);
            jta.setLineWrap(true);
            JScrollPane jsp = new JScrollPane(jta);
            add(jsp , BorderLayout.CENTER);
            JPanel bottomPanel = new JPanel(new BorderLayout());
            add (bottomPanel , BorderLayout.SOUTH);
            JButton jbSend = new JButton("SEND");
            bottomPanel.add (jbSend,BorderLayout.EAST);
            jtf = new JTextField ();
            bottomPanel.add (jtf, BorderLayout.CENTER);
            jbSend.addActionListener( new ActionListener() {
                @Override
                public void actionPerformed( ActionEvent e ) {
                    if (!jtf.getText().trim().isEmpty()) {
                        sendMsg();
                        jtf.grabFocus();
                    }
                }
            });

            jtf.addActionListener(new ActionListener () {
                @Override
                public void actionPerformed(ActionEvent e) {
                    sendMsg();
                }
            });

            new Thread( new Runnable () {
                @Override
                public void run () {
                    try {
                        while (true) {
                            if (in.hasNext()) {
                                String w = in.nextLine();
                                if ( w.equalsIgnoreCase( "end session" )) break ;
                                jta.append( w );
                                jta.append( "\n" );
                            }
                        }
                    } catch(Exception e) {
                    }
                }
            }).start();

            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    super.windowClosing(e);
                    try {
                        out.println("end");
                        out.flush();
                        out.close();
                        in.close();
                    } catch (Exception exc ) {
                        out.println(exc.getMessage());
                    }
                    finally { //super.sock.close();
                    }
                }
            });
            setVisible ( true );
            jta.append( "Сервер запущен, ожидаем подключения..." );
            jta.append( "\n" );
            sock = serv.accept();
            //sock = new Socket(SERVER_ADDR , SERVER_PORT);
            in = new Scanner(sock.getInputStream());
            out = new PrintWriter(sock.getOutputStream());
            //out.println("Сервер запущен, ожидаем подключения..." );
        } catch ( IOException e ) {
                e.printStackTrace();
        }
        try {
            jta.append( "Клиент подключился на порт "+sock.getPort() );
            jta.append( "\n" );
            Scanner sc = new Scanner(sock.getInputStream());
            //PrintWriter pw = new PrintWriter(sock.getOutputStream());
            while( true ) {
                String str = sc.nextLine();
                if ( str.equals( "end" )) break ;
                jta.append( str );
                jta.append( "\n" );
                    //out.println( "Эхо: " + str );
                    //out.flush ();
            }
        } catch( IOException e ) {
            jta.append( "Ошибка инициализации сервера" );
            jta.append( "\n" );
        } finally {
                try {
                    sock.close();
                    serv.close();
                } catch(IOException e) {
                    e.printStackTrace();
                }
        }
    }

    public void sendMsg () {
        out.println( jtf.getText());
        out.flush();
        jtf.setText("");
    }
}